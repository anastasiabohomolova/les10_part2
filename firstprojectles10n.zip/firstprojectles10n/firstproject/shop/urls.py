from django.urls import path
from shop.views import *
from django.conf import settings
from django.conf.urls.static import static


urlpatterns = [
    path('', shop_page),
    path('detail/<int:id>/', detail_page),
    path('category/', page_category),
    path('dresses/', page_dresses),
    path('bags/', page_bags),
    path('suits/', page_suits),
    path('create/', create_closes),
    path('update/<int:id>/', update_closes)
    ]







